import { Ordinateur } from './ordinateur';

describe('Ordinateur', () => {
  it('should create an instance', () => {
    expect(new Ordinateur()).toBeTruthy();
  });
});
